---
title: RStudio setup and Markdown
output: pdf_document
---

If we’re only doing text, i.e. no R code, using a .md file like this is
a good alternative.

## Why not use GitHub?

You may have used github projects in STA518. We are instead using
facilities of the RStudio server to manage, keep our work centralized  and share work.
GitHub’s public and collaborative nature is great for open-source projects, 
but sometimes it adds complexity and risk when dealing with sensitive or proprietary information.




## Posit Workbench (RStudio) Server

We will be using the GVSU RStudio Server, now called [Posit Workbench](http://rstudio.gvsu.edu). 
When you log into the server it creates a small linux virtual machine running RStudio. 
IT instructions for using the server are linked below.

[RStudio Server](https://services.gvsu.edu/TDClient/60/Portal/KB/ArticleDet?ID=2176)

## Markdown basics

Text blocks in RMarkdown (.Rmd) documents and in plain markdown (.md) documents use the MarkDown language to typeset documents. 
You can find tutorials and cheat sheets for RMarkdown under the Help menu in RStudio. 
In addition, a more comprehensive guide to use Markdown syntax can be found on the [Markdown Guide](https://www.markdownguide.org/basic-syntax/) page, along with best practices and cautions.



## Copy folder from SharedProjects

I will be working in a folder for each topic and will make a topic folder available under ~/SharedProjects/Appiah/STA631.
If you haven't already, create a personal STA631 folder in your home directory by following the steps below

First, we will open RStudio and create a new project.

a)	Click File > New Project… > New Directory > New Project. In the Directory name: field, type STA-631. Then click the Create Project button.

b) In the Files pane (bottom right), navigate to Home > SharedProjects > Appiah > STA631. Then, 
copy the new topic folder from our shared folder to your ~/STA631 folder.
.


Only open files for editing from your copy of the topic folder.
You can edit a file in the shared folder but will not be able to save it.
If this happens (you'll get an error when trying to save), just use SaveAs to save it back to your personal folder.

## Create, Edit files

Next we will create a new file (well, open a new-to-you file) and see how to save these changes RStudio’s graphical user interface.
We'll assume you have copied over the '00-Getting started' folder to your personal folders.

1.  In the **Files** pane in RStudio (lower right-hand pane), navigate
    to within the `00-Getting started` folder and click on to open the
    Rmarkdown file named `activity_start.Rmd`.
2.  Follow the directions in the **Introduction** section of this
    Rmarkdown file, then return back to these steps.

**You should currently be doing work in the `activity_start.Rmd` file.**

3.  Make sure to save your work in 'activity_start.Rmd'.


## Shared projects

We will often be doing group work and so will need to share files with other class members.
Project sharing is enabled on the RStudio server. 
You can find instructions at [IT's Knowledge Base article](https://services.gvsu.edu/TDClient/60/Portal/KB/ArticleDet?ID=21364).
